;(function () {
  // 屏幕大于800
  var designW = document.body.offsetWidth > 760 ? 2455 : 760 //设计稿宽
  var font_rate = document.body.offsetWidth > 760 ? 16 : 6 //设计稿宽
  // var designW = 1960
  // var font_rate = 16
  //适配
  document.getElementsByTagName('html')[0].style.fontSize = (document.body.offsetWidth / designW) * font_rate + 'px'
  document.getElementsByTagName('body')[0].style.fontSize = (document.body.offsetWidth / designW) * font_rate + 'px'
  //监测窗口大小变化
  window.addEventListener(
    'onorientationchange' in window ? 'orientationchange' : 'resize',
    function () {
      document.getElementsByTagName('html')[0].style.fontSize = (document.body.offsetWidth / designW) * font_rate + 'px'
      document.getElementsByTagName('body')[0].style.fontSize = (document.body.offsetWidth / designW) * font_rate + 'px'
    },
    false
  )
})()
